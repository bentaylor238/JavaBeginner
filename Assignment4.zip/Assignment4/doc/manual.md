            FRACTAL MAKING PROGRAM USER MANUAL

When the program is started the user will be prompted
for a file path to their configuration file, which 
should have an '.frac' file extension.

Here are 2 examples of the format of a configuration
file (one of a Julia fractal and one of a Mandelbrot
fractal) the items within the file can be written in
any order.
           
        type: Mandelbrot
        pixels:     640
        centerX:    0.30820836067024604
        centerY:    0.03062093623000417
        axisLength: 0.03
        Iterations: 100
        
        type: Julia
        cReal: -1
        cImag: 0
        pixels: 1024
        centerX: 0.0
        centerY: 0.0
        axisLength: 4.0
        iterations: 78

The program will then ask the user whether they would
like to input the Start and End Color that will be 
used to create a list of colors that gradient from
the start to the end, which is used to color the 
fractal. 

Entering 1, will allow the user their own defined
colors. Entering any other key will have the program
use preset default colors.

When the user inputs the colors, it needs to be 
entered as RGB values. Acceptable RGB values are any
integers between 0 and 256.

Once the coloring has been determined, the program
will then calculate and create the fractal, the 
program will automatically open and display the 
fractal, but it will also create and save the fractal
into a file which will be stored in the data directory.