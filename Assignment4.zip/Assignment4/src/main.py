from pathlib import Path
from Config import Config
from Julia import Julia
from Mandelbrot import Mandelbrot
from Grad2Colors import Grad2Colors
from Color import Color
from ImagePainter import ImagePainter

mandelbrotFiles = ['fullmandelbrot', 'spiral0', 'spiral1', 'seahorse', 'elephants', 'leaf']
juliaFiles = ['fulljulia', 'hourglass', 'lakes']

def getFile():
    valid = False
    while valid == False:
        print("Please specify a a fractal configuration file:")
        file = input()
        if file.endswith('.frac'):
            pass
        else:
            file = file + '.frac'
        file = Path(file)
        if file.is_file():
            valid = True
        if valid == False:
            print("Sorry, the file you gave does not exist. Here are some sample configuration file inputs that "
                  "will work")
            print("        MANDELBROT CONFIG FILE EXAMPLES:       ")
            for item in mandelbrotFiles:
                print(item)
            print()
            print("         JULIE CONFIG FILE EXAMPLES             ")
            for item in juliaFiles:
                print(item)
    if valid == True:
        conf = Config(file)
        grad = getColors(conf.iterations)
        create(conf, grad)

def getColors(iterations):
    valid = False
    choice = ''
    while valid == False:
        print("If you would like to select the colors for the gradient please enter 1, if you would like"
              "to use a predetermined default enter any key")
        choice = input()
        valid = True

    if choice == '1':
        print("Please enter the R G B values you would like your initial color in the gradient to be"
                  "(Valid values are from 0 to 256)")
        print("Initial R: ")
        initialR = input()
        print("Initial G: ")
        initialG = input()
        print("Initial B: ")
        initialB = input()

        initialColor = Color(initialR, initialG, initialB)

        print("Please enter the R G B values you would like your final color in the gradient to be"
                  "(Valid values are from 0 to 256)")
        print("Initial R: ")
        finalR = input()
        print("Initial G: ")
        finalG = input()
        print("Initial B: ")
        finalB = input()

        finalColor = Color(finalR, finalG, finalB)

        gradient = Grad2Colors(iterations, initialColor, finalColor)

    else:
        initialColor = Color(255, 0, 0)
        finalColor = Color(0, 255, 255)
        gradient = Grad2Colors(iterations, initialColor, finalColor)
    return gradient


def create(newConfig, gradient):
    length = len(gradient.colors)
    newConfig.setGradLength(length)
    ImagePainter(newConfig, gradient.colors)


getFile()