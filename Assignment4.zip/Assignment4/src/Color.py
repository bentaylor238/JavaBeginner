class Color():
    def __init__(self, r=0, g=0, b=0):
        self.r = 0
        self.g = 0
        self.b = 0

        self.setRed(r)
        self.setGrn(g)
        self.setBlu(b)

    def setRed(self, r):
        if r < 0:
            self.r = 0
        elif r > 255:
            self.r = 255
        else:
            self.r = int(r)

    def setGrn(self, g):
        if g < 0:
            self.g = 0
        elif g > 255:
            self.g = 255
        else:
            self.g = int(g)

    def setBlu(self, b):
        if b < 0:
            self.b = 0
        elif b > 255:
            self.b = 255
        else:
            self.b = int(b)

    def __str__(self):
        return f"#{self.r:02x}{self.g:02x}{self.b:02x}"
        # return f"Color({self.r},{self.g},{self.b})"

    def __repr__(self):
        return self.__str__()