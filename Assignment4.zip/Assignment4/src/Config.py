class Config():
    def __init__(self, fileName):
        self.file = fileName
        self.type = ''
        self.pixels = 0
        self.centerX = 0
        self.centerY = 0
        self.axislength = 0
        self.iterations = 0
        self.min = {'x': 0, 'y': 0}
        self.max = {'x': 0, 'y': 0}
        self.cReal = 0
        self.cImag = 0
        self.imagename = ''
        self.pixelSize = 0
        self.gradLength = 0
        self.c = 0

        self.readFile()

    def readFile(self):
        # treat missing/mispelled directives and values as errors
        with open(self.file, 'r') as file:
            for line in file:
                line = line.rstrip()
                line = line.replace(" ", "")
                line = line.lower()
                fullLine = line.split(':', maxsplit=1)

                if fullLine[0] == 'type':
                    self.type = fullLine[1]
                elif fullLine[0] == 'pixels':
                    self.pixels = int(fullLine[1])
                elif fullLine[0] == 'centerx':
                    self.centerX = float(fullLine[1])
                elif fullLine[0] == 'centery':
                    self.centerY = float(fullLine[1])
                elif fullLine[0] == 'axislength':
                    self.axislength = float(fullLine[1])
                elif fullLine[0] == 'iterations':
                    self.iterations = int(fullLine[1])
                elif fullLine[0] == 'cReal':
                    self.cReal = int(fullLine[1])
                elif fullLine[0] == 'cImag':
                    self.cImag = int(fullLine[1])

        self.min = (((self.centerX - self.axislength)/2.0), ((self.centerY + self.axislength)/2.0))
        self.max = (((self.centerX - self.axislength)/2.0), ((self.centerY + self.axislength)/2.0))
        self.pixelSize = (abs((self.max[0] - self.min[0])/self.pixels))
        if(self.type == 'julia'):
            self.c = complex(self.cReal, self.cImag)
        elif(self.type == 'mandelbrot'):
            self.c = (self.centerX, self.centerY)

        temp = self.file
        temp = str(temp)
        if temp.endswith('.frac'):
            self.imagename = temp[:-5]

    def setGradLength(self, len):
        self.gradLength = len
