class Julia():
    def __init__(self, iterations):
        self.it = iterations

    def count(self, c):
        z = complex(-1, 0)
        for i in range(self.it):
            z = z * z + c
            if abs(z) > 2:
                return i
        return self.it - 1
