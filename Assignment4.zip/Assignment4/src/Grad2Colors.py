from Gradient import Gradient

class Grad2Colors(Gradient):
    def __init__(self, steps, start, end):
        self.colors = self.linearlyInterpolate(steps, start, end)
