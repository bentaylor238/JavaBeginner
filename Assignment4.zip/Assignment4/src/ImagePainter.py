from tkinter import Tk, Canvas, PhotoImage, mainloop
from Mandelbrot import Mandelbrot
from Julia import Julia

class ImagePainter():
    def __init__(self, config, grad):
        self.window = Tk()
        self.gradient = grad
        self.config = config
        self.imgName = self.config.imagename
        self.type = self.config.type
        self.img = PhotoImage(width=config.pixels, height=config.pixels)
        self.create()

    def create(self):
        for c in range(self.config.pixels):
            for r in range(self.config.pixels):
                x = self.config.min[0] + c * self.config.pixelSize
                y = self.config.min[1] + r * self.config.pixelSize
                if self.type == 'mandelbrot':
                    mand = Mandelbrot(self.config.iterations)
                    colorNumber = mand.count(complex(x, y))
                else:
                    julia = Julia(self.config.iterations)
                    colorNumber = julia.count(complex(x,y))
                color = self.gradient[colorNumber]
                self.img.put(color, (c, r))
        canvas = Canvas(self.window, width=self.config.pixels, height=self.config.pixels, bg=self.gradient[0])
        canvas.pack()
        canvas.create_image((self.config.pixels/2, self.config.pixels/2), image=self.img, state="normal")

        # self.img.write(self.imgName + ".png")
        # print(f"Wrote image{self.imgName}.png")
        mainloop()


