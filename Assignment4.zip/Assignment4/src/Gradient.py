from Color import Color

class Gradient():
    def __init__(self):
        pass
    # raiseNotImplementedError("Don't instantiate a Gradient, instantiate a subclass of Gradient")

    def getColor(self, n):
        return self.colors[n-1]

    def getFirstColor(self):
        return self.colors[0]

    def getLastColor(self):
        return self.colors[-1]

    def getNumColors(self):
        return len(self.colors)

    def linearlyInterpolate(self, steps, start, stop):
        dRed = (stop.r - start.r) / (steps - 1)
        dGrn = (stop.g - start.g) / (steps - 1)
        dBlu = (stop.b - start.b) / (steps - 1)
        return list(
            map(lambda n: Color((n * dRed) + start.r, (n * dGrn) + start.g, (n * dBlu) + start.b), range(steps)))
