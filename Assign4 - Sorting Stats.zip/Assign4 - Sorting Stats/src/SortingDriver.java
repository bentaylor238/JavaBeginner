/**
 * Assignment 4 for CS 1410
 * This program evaluates the bubble and selection sorts versus each other.
 *
 * @author James Dean Mathias
 */
public class SortingDriver {
    public static void main(String[] args) {

    }

}
