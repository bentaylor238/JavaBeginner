import java.util.ArrayList;

/**
 * @brief This class holds the game play arena for all of the game entities.  It exposes
 * methods for adding entities, moving the hero, and for retrieving the status of entities
 * it contains.
 *
 * @author James Dean Mathias
 */
public class Arena {
    private ArrayList<Entity[]> grid;
    private Hero hero;

    public Arena(int sizeX, int sizeY) {
        /** TODO */
    }

    public ArrayList<Entity[]> getGrid() { return this.grid; }

    /**
     * @brief Used to add a new entity to the arena.  The entity is stored at the location indicated
     * by the entity position.  If an entity is already in that position, the new one isn't added and
     * false is returned to indicate this.  When the hero is added, the reference to the hero (on the class)
     * is set at that time, in addition being added to the arena.
     */
    public boolean add(Entity e) {
        /** TODO */
    }

    public void moveHero(int x, int y) {
        /** TODO */
    }

    public void reportHero() {
        this.hero.report();
    }

    /**
     * @brief Public methods exposed primarily for unit testing purposes, but these could
     * reasonably be expected in a "real" application.
     */
    public Hero getHero() {
        return this.hero;
    }

    public int getEntityCount() {
        /** TODO */
    }

    public int getDragonCount() {
        /** TODO */
    }

    public int getTreasureCount(Treasure type) {
        /** TODO */
    }
}
